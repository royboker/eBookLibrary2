﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace eBookLibrary3.Controllers
{
    public class ViewtestController : Controller
    {
        // GET: Viewtest
        public ActionResult View()
        {
            return View();
        }
    }
}
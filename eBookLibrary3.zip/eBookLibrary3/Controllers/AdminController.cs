﻿using eBookLibrary3.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.Entity;
namespace eBookLibrary3.Controllers
{
    public class AdminController : Controller
    {
        // GET: Admin
        //public ActionResult Index()
        //{
        //    return View();
        //}

        //הצגת הספריה של האדמין בה הוא יכול לערוך ולמחוק ספרים קיימים
        public ActionResult ShowAdminLibrary()
        {
            using (var db = new LibraryContext())
            {

                var books = db.Books.ToList();
                //foreach (var book in books)
                //{
                //    if (book.DiscountStartDate.HasValue)
                //    {
                //        if ((DateTime.Now - book.DiscountStartDate.Value).TotalDays >= 7)
                //        {
                //            book.BuyPrice = 0;
                //            book.DiscountStartDate = null;
                //        }
                //    }
                //}
                return View(books);
            }
        }

        //דף עריכת ספר ספציפי 
        [HttpGet]
        public ActionResult EditBook(int bookId)
        {
            //שליפת נתוני הספר שנרצה לערוך
            using (var db = new LibraryContext())
            {
                var book = db.Books.FirstOrDefault(b => b.BookId == bookId);
                if (book == null)
                {
                    return HttpNotFound();
                }
                return View(book); // הצגת פרטי הספר לעריכה
            }
        }


        //בדיקת התקינות של קלטי הטופס ועדכון פרטי הספק בהתאם
        [HttpPost]
        public ActionResult EditBook(Book updatedBook)
        {
            using (var db = new LibraryContext())
            {
                var book = db.Books.FirstOrDefault(b => b.BookId == updatedBook.BookId);
                if (book != null)
                {
                    // בדיקת עדכון מחיר קנייה
                    if (updatedBook.BuyPrice != book.BuyPrice)
                    {
                        if (updatedBook.BuyPrice == 0)
                        {
                            // עדכון מחיר קנייה למחיר המקורי
                            book.BuyPrice = book.Price;
                            book.DiscountStartDate = null;
                        }
                        else if (updatedBook.BuyPrice > book.Price)
                        {
                            TempData["Message"] = "Book sale price must be below the original price.";
                            return RedirectToAction("ShowAdminLibrary");
                        }
                        else
                        {
                            // עדכון מחיר קנייה ותאריך הנחה
                            book.BuyPrice = updatedBook.BuyPrice;
                            book.DiscountStartDate = DateTime.Now;
                        }
                    }

                    // בדיקת עדכון מחיר השאלה
                    if (updatedBook.BorrowPrice > 0)
                    {
                        if (updatedBook.BorrowPrice >= book.Price || (book.BuyPrice > 0 && updatedBook.BorrowPrice >= book.BuyPrice))
                        {
                            TempData["Message"] = "Borrow price must be below the original price and the sale price.";
                            return RedirectToAction("ShowAdminLibrary");
                        }
                        book.BorrowPrice = updatedBook.BorrowPrice;
                    }
                    if(updatedBook.BorrowPrice ==0)
                    {
                        book.BorrowPrice = 0;
                    }

                    // עדכון שדות נוספים
                    book.Stock = updatedBook.Stock;
                    book.Genre = updatedBook.Genre;

                    db.SaveChanges(); // שמירת שינויים
                }

                TempData["Message"] = "Book details updated successfully.";
                return RedirectToAction("ShowAdminLibrary");
            }
        }

        //מחיקת ספר בידי המנהל מהספריה
        public ActionResult DeleteBook(int bookId)
        {
            //מציאת הספר הרוולנטי
            using (var db = new LibraryContext())
            {
                var book = db.Books.FirstOrDefault(b => b.BookId == bookId);
                if (book != null)
                {
                    db.Books.Remove(book); // מחיקת הספר
                    db.SaveChanges();
                }
                TempData["Message"] = "Book deleted successfully.";
                return RedirectToAction("ShowAdminLibrary");
            }
        }


        //הצגת טבלה של הכל המשתשמים הרשומים באתר עבור כל אחד נראה את הספרים שקנה ושהשאיל ניתן לערוך פרטי משתמש ולמחוק פרטי משתמש
        public ActionResult ViewUsers()
        {
            using (var db = new LibraryContext())
            {
                var users = db.Users
                    .Where(u => u.RoleId == 2) // סינון משתמשים רגילים בלבד
                    .Include("Borrows.Book") // טוען את הספרים המושאלים
                    .Include("Purchases.Book") // טוען את הספרים שנרכשו
                    .ToList();

                return View(users);
            }
        }

        //עריכת פרופיל של משתמש מסוג אדמין
        public ActionResult EditProfile()
        {
            int adminId = (int)Session["UserId"]; // מזהה האדמין המחובר
            using (var db = new LibraryContext())
            {
                var admin = db.Users.FirstOrDefault(u => u.UserId == adminId);
                if (admin == null)
                {
                    return HttpNotFound();
                }
                return View(admin);
            }
        }

        //ערכית פרטי אדמין
        [HttpPost]
        public ActionResult EditProfile(User updatedAdmin)
        {
            using (var db = new LibraryContext())
            {
                var admin = db.Users.FirstOrDefault(u => u.UserId == updatedAdmin.UserId);
                if (admin != null)
                {
                    admin.FirstName = updatedAdmin.FirstName;
                    admin.Email = updatedAdmin.Email;
                    admin.PasswordHash = updatedAdmin.PasswordHash; // אם מתאפשר
                    db.SaveChanges();
                }
                return RedirectToAction("AdminDashboard");
            }
        }

        //טופס הוספת ספר
        [HttpGet]
        public ActionResult AddBook()
        {
            // מציג טופס ריק להוספת ספר
            return View(new Book());
        }

        //הוספת ספר חדש לספריה בהתאם לתנאים שהוגדו
        [HttpPost]
        public ActionResult AddBook(Book newBook)
        {
            if (!ModelState.IsValid)
            {
                return View(newBook); // החזרת הטופס במקרה של שגיאה בנתונים
            }

            using (var db = new LibraryContext())
            {
                // בדיקה אם כבר קיים ספר עם אותו שם
                var existingBook = db.Books.FirstOrDefault(b => b.Title.Equals(newBook.Title, StringComparison.OrdinalIgnoreCase));
                if (existingBook != null)
                {
                    TempData["Message"] = "A book with the same title already exists.";
                    return View(newBook);
                }

                // בדיקת תקינות מחירים
                if (newBook.Price <= 0)
                {
                    TempData["Message"] = "Original price must be greater than 0.";
                    return View(newBook);
                }

                if (newBook.BuyPrice > 0 && newBook.BuyPrice >= newBook.Price)
                {
                    TempData["Message"] = "Sale price must be less than the original price.";
                    return View(newBook);
                }

                if (newBook.BorrowPrice > 0 && (newBook.BorrowPrice >= newBook.Price || (newBook.BuyPrice > 0 && newBook.BorrowPrice >= newBook.BuyPrice)))
                {
                    TempData["Message"] = "Borrow price must be less than the original price and sale price (if provided).";
                    return View(newBook);
                }
                if(newBook.BuyPrice ==0)
                {
                    newBook.BuyPrice = newBook.Price;
                }

                // קביעת ערכים ברירת מחדל
                newBook.Stock = 3;
                newBook.Popularity = 0;
                newBook.ReviewCount = 0;
                newBook.Format = "PDF, EPUB, MOBI, F2B";

                // הגדרת מחיר קנייה אם הוא לא הוזן
                if (newBook.BuyPrice == 0)
                {
                    newBook.BuyPrice = newBook.Price;
                }

                // הגדרת תאריך התחלת הנחה אם יש מחיר הנחה
                if (newBook.BuyPrice > 0)
                {
                    newBook.DiscountStartDate = DateTime.Now;
                }

                // הוספת הספר למסד הנתונים
                db.Books.Add(newBook);
                db.SaveChanges();
            }

            TempData["Message"] = "Book added successfully.";
            return RedirectToAction("ShowAdminLibrary");
        }


        
        [HttpPost]
        public ActionResult DeleteUser(int userId)
        {
            using (var db = new LibraryContext())
            {
                // מציאת המשתמש לפי ID
                var user = db.Users.FirstOrDefault(u => u.UserId == userId);

                if (user != null)
                {
                    // 1. טיפול בהשאלות פעילות
                    var activeBorrows = db.Borrows.Where(b => b.UserId == userId && b.ReturnDate > DateTime.Now).ToList();
                    foreach (var borrow in activeBorrows)
                    {
                        var book = db.Books.FirstOrDefault(b => b.BookId == borrow.BookId);
                        if (book != null)
                        {
                            // הגדלת המלאי של הספר
                            book.Stock += 1;
                        }

                        // מחיקת ההשאלה
                        db.Borrows.Remove(borrow);
                    }

                    // 2. טיפול ברשימות המתנה
                    var waitingListEntries = db.WaitingLists.Where(w => w.UserId == userId).ToList();
                    foreach (var entry in waitingListEntries)
                    {
                        // מחיקת המשתמש מרשימת ההמתנה
                        db.WaitingLists.Remove(entry);

                        // עדכון הפוזיציות של המשתמשים האחרים ברשימת ההמתנה עבור אותו ספר
                        var waitingList = db.WaitingLists
                            .Where(w => w.BookId == entry.BookId && w.Position > entry.Position)
                            .OrderBy(w => w.Position)
                            .ToList();

                        foreach (var waitingUser in waitingList)
                        {
                            waitingUser.Position--;
                        }
                    }

                    // שמירת שינויים (עדכון מלאי ועדכון רשימות המתנה)
                    db.SaveChanges();


                    // 3. טיפול ברכישות
                    var purchases = db.Purchases.Where(p => p.UserId == userId).ToList();
                    foreach (var purchase in purchases)
                    {
                        db.Purchases.Remove(purchase);
                    }

                    // 5. מחיקת המשתמש עצמו
                    db.Users.Remove(user);

                    // 6. שמירת שינויים
                    db.SaveChanges();
                }

                TempData["Message"] = "User deleted successfully.";
                return RedirectToAction("ViewUsers");
            }
        }

        //עריכת פרטי משתמש ספציפי
        [HttpGet]
        public ActionResult EditUser(int id)
        {
            using (var db = new LibraryContext())
            {
                var user = db.Users.Find(id);
                if (user == null)
                {
                    return HttpNotFound();
                }

                var model = new EditUserViewModel
                {
                    UserId = user.UserId,
                    FirstName = user.FirstName,
                    LastName = user.LastName,
                    Email = user.Email
                };

                return View(model);
            }
        }


        //פונקציה עבור עדכון פרטי המתממש תוך כדי בדיקות תקינות
        [HttpPost]
        public ActionResult EditUser(EditUserViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }

            using (var db = new LibraryContext())
            {
                var user = db.Users.Find(model.UserId);

                if (user == null)
                {
                    return HttpNotFound();
                }

                if (!string.IsNullOrEmpty(model.FirstName))
                {
                    user.FirstName = model.FirstName;
                }
                if (!string.IsNullOrEmpty(model.LastName))
                {
                    user.LastName = model.LastName;
                }
                if (!string.IsNullOrEmpty(model.Email))
                {
                    user.Email = model.Email;
                }

                db.SaveChanges();
            }

            TempData["Message"] = "User details updated successfully.";
            return RedirectToAction("ViewUsers");
        }





    }
}
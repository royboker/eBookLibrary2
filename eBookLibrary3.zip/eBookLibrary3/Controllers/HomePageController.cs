﻿using eBookLibrary3.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace eBookLibrary3.Controllers
{
    public class HomePageController : Controller
    {
        //הצגת דף הבית עם הספרים הפופלרים ביותר
        public ActionResult ShowHomePage()
        {
           // ManageBorrows();
          //  NotifyUsersAboutBorrowExpiry();
            using (var db = new LibraryContext())
            {
                var books = db.Books.AsQueryable();

                foreach (var book in books)
                {
                    if (book.DiscountStartDate.HasValue)
                    {
                        if ((DateTime.Now - book.DiscountStartDate.Value).TotalDays >= 7)
                        {
                            book.BuyPrice = book.Price;
                            book.DiscountStartDate = null;
                        }
                    }
                }
                db.SaveChanges();

                // שליפת הספרים הפופולריים
                var popularBooks = db.Books
                    .OrderByDescending(b => b.Popularity)
                    .Take(6) // מספר הספרים לסרט הנע
                    .ToList();



                return View(popularBooks);
            }


        }
        //הצגת דף אודות האתר עם נתונים כללים עבור המשתמש
        public ActionResult About()
        {
            using (var db = new LibraryContext())
            {
                // חישוב מספר המשתמשים והספרים הרכישות והביקורות
                var totalUsers = db.Users.Count();
                var totalBooks = db.Books.Count();
                var totalReviews = db.SiteReviews.Count();
                var totalPurchases = db.Purchases.Count();
                var totalBorrows = db.Borrows.Count();
                var totalshoping  = totalBorrows+ totalPurchases;

                // שליחת המידע לדף ה-About
                ViewBag.TotalUsers = totalUsers;
                ViewBag.TotalBooks = totalBooks;
                ViewBag.TotalReviews = totalReviews;
                ViewBag.TotalShoping = totalshoping;
                

                ViewBag.LatestReviews = db.SiteReviews
                          .OrderByDescending(r => r.Rating)
                          .ThenByDescending(r => r.CreatedAt) // למקרה של דירוגים שווים, נמיין לפי תאריך יצירה
                          .Take(10)
                          .ToList();
            
            }

            return View();
        }

        //ניהול השלאות דף הבית הוא הדף שעושה את בדיקות של הזמנים השונים בהתאם לתנאי האתר
        public void ManageBorrows()
        {
            using (var db = new LibraryContext())
            {
                // שלב 1: מחיקת השאלות שפג תוקפן והגדלת המלאי
                var expiredBorrows = db.Borrows
                    .Include("Book")
                    .Where(b => b.ReturnDate < DateTime.Now)
                    .ToList();

                var updatedBooks = new HashSet<int>(); // סט של מזהי ספרים שחזרו למלאי

                foreach (var borrow in expiredBorrows)
                {
                    var book = borrow.Book;

                    if (book != null)
                    {
                        book.Stock += 1; // הגדלת המלאי עבור הספר
                        updatedBooks.Add(book.BookId); // הוספת הספר לרשימת הספרים שחזרו למלאי
                    }

                    db.Borrows.Remove(borrow); // מחיקת השורה מהטבלה
                }

                db.SaveChanges();

                // שלב 2: טיפול ברשימת ההמתנה
                // הסרת משתמשים שחלף חודש מאז שנוספו
                var expiredWaitingListEntries = db.WaitingLists
                    .Where(w => DbFunctions.DiffDays(w.AddedAt, DateTime.Now) > 30)
                    .ToList();

                foreach (var entry in expiredWaitingListEntries)
                {
                    db.WaitingLists.Remove(entry); // הסרת המשתמש מרשימת ההמתנה

                    // עדכון פוזיציות של שאר המשתמשים ברשימה
                    var waitingList = db.WaitingLists
                        .Where(w => w.BookId == entry.BookId && w.Position > entry.Position)
                        .OrderBy(w => w.Position)
                        .ToList();

                    foreach (var waitingUser in waitingList)
                    {
                        waitingUser.Position--; // קידום הפוזיציה
                    }
                }

                db.SaveChanges();

                // ששליחת מייל לשלושת הראשונים ברשימת ההמתנה עבור ספרים שחזרו למלאי בלבד
                foreach (var bookId in updatedBooks)
                {
                    var book = db.Books.AsNoTracking().FirstOrDefault(b => b.BookId == bookId);

                    if (book != null && book.Stock > 0)
                    {
                        var waitingList = db.WaitingLists
                            .Where(w => w.BookId == bookId)
                            .OrderBy(w => w.Position)
                            .Take(3)
                            .ToList();

                        foreach (var waitingEntry in waitingList)
                        {
                            var user = db.Users.AsNoTracking().FirstOrDefault(u => u.UserId == waitingEntry.UserId);
                            if (user != null)
                            {
                                // שליחת מייל
                                var emailService = new EmailService("smtp.gmail.com", 587, "royboker15@gmail.com", "dhue jxxw dhbd wdpl");
                                string subject = $"The book '{book.Title}' is now available!";
                                string body = $"Hello {user.FirstName},\n\nThe book '{book.Title}' is now available for you to borrow. Please log in to your account to complete the borrowing process.";
                                emailService.SendEmail(user.Email, subject, body, true);

                               
                            }
                        }
                    }
                }

                db.SaveChanges(); // שמירת השינויים
            }
        }

        //פונקציה המודיעה למשתשמים שיש להם ספרים מושאלים בספריה שלהם עם עוד חמש ימים נגמרת להם הששאלה 
        public void NotifyUsersAboutBorrowExpiry()
        {
            using (var db = new LibraryContext())
            {
                // שליפת כל השאלות עם תאריך החזרה בעוד 5 ימים או פחות
                var upcomingExpiryBorrows = db.Borrows
                    .Include("Book") // טוען את הספרים מראש
                    .Include("User") // טוען את המשתמשים מראש
                    .Where(b => DbFunctions.DiffDays(DateTime.Now, b.ReturnDate) <= 5 && DbFunctions.DiffDays(DateTime.Now, b.ReturnDate) >= 0)
                    .ToList();

                foreach (var borrow in upcomingExpiryBorrows)
                {
                    var user = borrow.User;
                    var book = borrow.Book;

                    if (user != null && book != null)
                    {
                        // חישוב מספר הימים שנותרו להחזרת הספר
                        int daysLeft = (int)(borrow.ReturnDate - DateTime.Now).TotalDays;

                        // שליחת מייל למשתמש
                        var emailService = new EmailService("smtp.gmail.com", 587, "royboker15@gmail.com", "dhue jxxw dhbd wdpl");
                        string subject = "Reminder: Your borrowed book is due soon";
                        string body = $@"
                            Dear {user.FirstName},

                            The book '{book.Title}' that you borrowed on {borrow.BorrowDate:dd/MM/yyyy}
                            will be due in {daysLeft} day(s).

                            Please note that the book will disappear from your library after the return date.

                            Best regards,
                            eBook Team";

                        emailService.SendEmail(user.Email, subject, body, true);
                    }
                }
            }
        }

    }
}
﻿using eBookLibrary3.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.Entity;

using System.Security.Cryptography;
using System.Text;

namespace eBookLibrary3.Controllers
{
    public class AccountController : Controller
    {
        // פעולה הפנייה לדף ההרשמה
        public ActionResult Register()
        {
            return View();
        }
        public ActionResult SubmitAccount(User model, string RePassword)
        {
            if (ModelState.IsValid)
            {
                // בדיקה האם הסיסמאות זהות
                if (model.PasswordHash != RePassword)
                {
                    TempData["Message"] = "Passwords do not match!";
                    return View("Register", model);
                }

                using (var db = new LibraryContext())
                {
                    // בדיקת האם המייל כבר קיים
                    var existingUser = db.Users.FirstOrDefault(u => u.Email == model.Email);
                    if (existingUser != null)
                    {
                        TempData["Message"] = "Email already exists! Please try another email.";
                        return View("Register", model);
                    }

                    // הצפנת הסיסמה לפני שמירה
                    // model.PasswordHash = PasswordHelper.HashPassword(model.PasswordHash);

                    using (var sha256 = SHA256.Create())
                    {
                        byte[] bytes = Encoding.UTF8.GetBytes(model.PasswordHash);
                        byte[] hash = sha256.ComputeHash(bytes);
                        model.PasswordHash = BitConverter.ToString(hash).Replace("-", "").ToLower();
                    }
                    // ברירת מחדל - תפקיד משתמש רגיל
                    model.RoleId = 2;

                    // הוספת המשתמש למסד הנתונים
                    db.Users.Add(model);
                    db.SaveChanges();
                }

                // הפניה לדף ההתחברות לאחר הרשמה מוצלחת
                TempData["Message"] = "Registration successful! Please log in.";
                return RedirectToAction("Login", "Account");
            }

            // חזרה לדף ההרשמה במקרה של שגיאה בנתונים
            TempData["Message"] = "Invalid registration details. Please try again.";
            return View("Register", model);
        }


        // פעולה לדף ההתחברות
        public ActionResult Login()
        {
            return View();
        }

        // פעולה לדף ההתחברות
        public ActionResult SubmitLogin(string Email, string PasswordHash)
        {
            using (var db = new LibraryContext())
            {
                // מצא את המשתמש לפי המייל
                var user = db.Users.FirstOrDefault(u => u.Email == Email);
                if (user == null)
                {
                    TempData["Message"] = "LoginError , User not found.";
                    return View("Login");
                }

                // הצפן את הסיסמה שהוזנה והשווה
                // string hashedPassword = PasswordHelper.HashPassword(PasswordHash);

                string hashedPassword;
                using (var sha256 = SHA256.Create())
                {
                    byte[] bytes = Encoding.UTF8.GetBytes(PasswordHash);
                    byte[] hash = sha256.ComputeHash(bytes);
                    hashedPassword = BitConverter.ToString(hash).Replace("-", "").ToLower();
                }
                if (user.PasswordHash != hashedPassword)
                {
                    TempData["Message"] = "Invalid password.";
                    return View("Login");
                }

                // התחברות הצליחה
                Session["UserId"] = user.UserId; // שמירת מזהה המשתמש בסשן
                Session["UserName"] = user.FirstName;
                Session["Role"] = user.RoleId;
                Session["Email"] = user.Email;
                return RedirectToAction("Dashboard", "Account");
            }
        }


        public ActionResult Dashboard()
        {
            if (!IsUserLoggedIn())
            {
                return RedirectToAction("Login", "Account");
            }

            // בדיקת תפקיד המשתמש
            int roleId = (int)Session["Role"];
            if (roleId == 2) // 2 = משתמש רגיל
            {
                return View("UserDashboard");
            }
            else if (roleId == 1) // 1 = Admin
            {
                return View("AdminDashboard");
            }

            // במקרה של תפקיד לא מוכר
            TempData["ErrorMessage"] = "Unauthorized access.";
            return RedirectToAction("Login", "Account");
        }

        //בדיקה האם משתמש מחובר
        private bool IsUserLoggedIn()
        {
            return Session["UserId"] != null;
        }


        //הצגת דף עדכון פרטי משתמש 
        [HttpGet]
        public ActionResult UpdateDetails()
        {
            if (Session["UserId"] == null)
            {
                return RedirectToAction("Login", "Account");
            }

            using (var db = new LibraryContext())
            {
                var userId = (int)Session["UserId"];
                var user = db.Users.Find(userId);
                return View(user);
            }
        }

        //עדכון פרטי המתמש 
        [HttpPost]
        public ActionResult UpdateDetails(User model)
        {
            //בדיקה שהמתמש מחובר
            if (Session["UserId"] == null)
            {
                return RedirectToAction("Login", "Account");
            }

            if (ModelState.IsValid)
            {
                using (var db = new LibraryContext())
                {
                    //עדכון פהרטים בהתאם לשדות שהוזנו
                    var user = db.Users.Find(model.UserId);
                    if (user != null)
                    {
                        user.FirstName = model.FirstName;
                        user.LastName = model.LastName;
                        user.Email = model.Email;
                        user.PasswordHash = PasswordHelper.HashPassword(model.PasswordHash);

                        db.SaveChanges();
                    }
                }


                TempData["Message"] = "Details updated successfully!";
                return RedirectToAction("Dashboard");
            }

            return View(model);
        }
        //ניתוק המשתתמש מהמערכת
        public ActionResult Logout()
        {
            // נקה את ה-Session
            Session.Clear();
            Session.Abandon();

            // הפנה לדף הבית או לדף התחברות
            return RedirectToAction("ShowHomePage", "HomePage");
        }

        //הצגת רכישות הספרים של המשתמש
        public ActionResult UserPurchases()
        {
            if (Session["UserId"] == null)
            {
                TempData["ErrorMessage"] = "You must be logged in to view your purchases.";
                return RedirectToAction("Login", "Account");
            }

            //שליפת הספרים הרלונטים מהמסד נתונים
            using (var db = new LibraryContext())
            {
                var userId = (int)Session["UserId"];
                var purchases = db.Purchases
                                  .Where(p => p.UserId == userId)
                                  .Include(p => p.Book) 
                                  .Select(p => new PurchaseViewModel
                                  {
                                      PurchaseId = p.PurchaseId,
                                      Title = p.Book.Title,
                                      Author = p.Book.Author,
                                      ImageUrl = p.Book.ImageUrl,
                                      PurchaseDate = p.PurchaseDate,
                                      Price = p.Book.BuyPrice,
                                      BookId = p.Book.BookId,
                                  })
                                  .ToList();

                return View(purchases);
            }
        }

        //הצגת ההשאלות של המשתמש
        public ActionResult MyBorrows()
        {
            int userId = (int)Session["UserId"];
            //שליפת הספרים הרלוונטים
            using (var db = new LibraryContext())
            {
                var borrows = db.Borrows
                    .Where(b => b.UserId == userId && b.ReturnDate > DateTime.Now)
                    .Include(b => b.Book)
                    .ToList();

                return View(borrows);
            }
        }


        //הצגת דף שכחתי סיסמא
        [HttpGet]
        public ActionResult ForgotPassword()
        {
            return View();
        }

        //תהליך שחזור הסיסמא
        [HttpPost]
        public ActionResult ForgotPassword(string email)
        {
            using (var db = new LibraryContext())
            {
                var user = db.Users.FirstOrDefault(u => u.Email == email);
                if (user == null)
                {
                    ModelState.AddModelError("", "Email not found.");
                    return View();
                }

                // יצירת טוקן אקראי
                string token = Guid.NewGuid().ToString();
                user.PasswordResetToken = token;
                db.SaveChanges();

                // שליחת הטוקן למייל של המשתמש
                var emailService = new EmailService("smtp.gmail.com", 587, "royboker15@gmail.com", "dhue jxxw dhbd wdpl");
                string subject = "Password Reset Request";
                string body = $"Hello,\n\nYour password reset token is: {token}\nPlease enter this code on the reset password page.";
                emailService.SendEmail(user.Email, subject, body, true);

                TempData["Message"] = "Password reset token has been sent to your email.";
                return RedirectToAction("EnterResetToken");
            }
        }

        //קבלת הטוקן שנשלח למשתמש לבדיקת תקינות 
        [HttpGet]
        public ActionResult EnterResetToken()
        {
            return View();
        }

        //בדיקה האם הטוקן תקין
        [HttpPost]
        public ActionResult EnterResetToken(string email, string token)
        {
            using (var db = new LibraryContext())
            {
                var user = db.Users.FirstOrDefault(u => u.Email == email && u.PasswordResetToken == token);
                if (user == null)
                {
                    TempData["Message"] = "Invalid email or token.";
                    return View();
                }

                // שמירת מזהה המשתמש ב-Session לצורך איפוס הסיסמה
                Session["ResetPasswordUserId"] = user.UserId;

                return RedirectToAction("ResetPassword");
            }
        }
        //דף הצגת טופס איפוס סיסמא
        [HttpGet]
        public ActionResult ResetPassword()
        {
            if (Session["ResetPasswordUserId"] == null)
            {
                return RedirectToAction("ForgotPassword");
            }

            return View();
        }


        //איפוס הסיסמא בהתאם לתנאים
        [HttpPost]
        public ActionResult ResetPassword(string newPassword, string confirmPassword)
        {
            if (Session["ResetPasswordUserId"] == null)
            {
                return RedirectToAction("ForgotPassword");
            }

            if (newPassword != confirmPassword)
            {
                TempData["Message"] = "Passwords do not match.";
                return View();
            }

            using (var db = new LibraryContext())
            {
                int userId = (int)Session["ResetPasswordUserId"];
                var user = db.Users.FirstOrDefault(u => u.UserId == userId);

                if (user == null)
                {
                    return HttpNotFound();
                }

                // עדכון הסיסמא והחזרת השדה של הטוקן ל-null
                user.PasswordHash = PasswordHelper.HashPassword(newPassword);
                user.PasswordResetToken = null;
                db.SaveChanges();

                // שליחת מייל על שינוי הסיסמא
                var emailService = new EmailService(
                    "smtp.gmail.com", // שרת ה-SMTP
                    587,              // פורט ה-SMTP
                    "royboker15@gmail.com", // כתובת המייל שלך
                    "dhue jxxw dhbd wdpl"     // סיסמת האפליקציה שלך
                );

                string subject = "Password Changed Successfully";
                string body = $@"
            <p>Dear {user.FirstName},</p>
            <p>Your password has been successfully changed.</p>
            <p>If you did not make this change, please contact our support team immediately.</p>
            <br>
            <p>Best regards,<br>eBookLibrary Team</p>
        ";

                emailService.SendEmail(user.Email, subject, body, true);
            }

            // ניקוי ה-Session
            Session["ResetPasswordUserId"] = null;

            TempData["Message"] = "Your password has been updated successfully.";
            return RedirectToAction("Login");
        }

        //הצגת הזמנות של המשתמש
        public ActionResult UserOrders()
        {
            if (Session["UserId"] == null)
            {
                TempData["ErrorMessage"] = "You must be logged in to view your orders.";
                return RedirectToAction("Login", "Account");
            }
            //שליפת הספרים הרלונטיים מהמסד נתונים
            using (var db = new LibraryContext())
            {
                int userId = (int)Session["UserId"];
                var orders = db.Orders
                               .Where(o => o.UserId == userId)
                               .ToList();

                var totalOrders = orders.Count;
                var totalAmount = orders.Sum(o => o.TotalAmount);

                ViewBag.TotalOrders = totalOrders;
                ViewBag.TotalAmount = totalAmount;

                return View(orders);
            }
        }
        //הצגת התשלומים של המשתמש
        public ActionResult UserPayments()
        {
            if (Session["UserId"] == null)
            {
                TempData["ErrorMessage"] = "You must be logged in to view your payments.";
                return RedirectToAction("Login", "Account");
            }
            //שליפת הספרים הרלוונטים מהמסד נתונים
            using (var db = new LibraryContext())
            {
                int userId = (int)Session["UserId"];
                var payments = db.Payments
                                 .Where(p => p.UserId == userId)
                                 .ToList(); // מחזיר רשימת Payments במקום אובייקטים אנונימיים

                var totalPayments = payments.Count;
                var totalAmountPaid = payments.Sum(p => p.Amount);

                ViewBag.TotalPayments = totalPayments;
                ViewBag.TotalAmountPaid = totalAmountPaid;

                return View(payments);
            }
        }


        //הצגת הספריה האישית של המשתמש
        public ActionResult MyLibrary()
        {
            if (Session["UserId"] == null)
            {
                TempData["ErrorMessage"] = "You must be logged in to access your library.";
                return RedirectToAction("Login", "Account");
            }

            using (var db = new LibraryContext())
            {
                var userId = (int)Session["UserId"];

                // ספרים שנרכשו
                var purchasedBooks = db.Purchases
                    .Where(p => p.UserId == userId)
                    .Include(p => p.Book)
                    .Select(p => new PurchaseViewModel
                    {
                        PurchaseId = p.PurchaseId,
                        Title = p.Book.Title,
                        Author = p.Book.Author,
                        ImageUrl = p.Book.ImageUrl,
                        PurchaseDate = p.PurchaseDate,
                        Price = p.Book.BuyPrice,
                        BookId = p.Book.BookId,
                    })
                    .ToList();

                // ספרים מושאלים
                var borrowedBooks = db.Borrows
                    .Where(b => b.UserId == userId && b.ReturnDate > DateTime.Now)
                    .Include(b => b.Book)
                    .ToList();

                //אם אין למשתמש עדיין ספרים בספריה שלו היא לא צומג
                if (!borrowedBooks.Any() && !purchasedBooks.Any())
                {
                    TempData["ErrorMessage"] = "Your Library is empty go buy or borrow books!!";
                    return RedirectToAction("ShowLibrary", "Library");
                }
                var model = new MyLibraryViewModel
                {
                    PurchasedBooks = purchasedBooks,
                    BorrowedBooks = borrowedBooks
                };

                return View(model);
            }
        }


        //הצגת דף הוספת ביקורת על האתר
        [HttpGet]
        public ActionResult AddReview()
        {
            if (Session["UserId"] == null)
            {
                TempData["ErrorMessage"] = "You need to log in to add a review.";
                return RedirectToAction("Login", "Account");
            }

            return View();
        }

        //קבלת הביקרות ועדכון
        [HttpPost]
        public ActionResult AddReview(string content, float rating)
        {
            if (Session["UserId"] == null)
            {
                TempData["ErrorMessage"] = "You need to log in to add a review.";
                return RedirectToAction("Login", "Account");
            }

            using (var db = new LibraryContext())
            {
                int userId = (int)Session["UserId"];
                string userName = (string)Session["UserName"];

                if (rating < 0 || rating > 5)
                {
                    TempData["Message"] = "Rating must be between 0 and 5.";
                    return RedirectToAction("AddReview");
                }

                var review = new SiteReview
                {
                    UserId = userId,
                    UserName = userName,
                    Content = content,
                    Rating = rating,
                    CreatedAt = DateTime.Now
                };

                db.SiteReviews.Add(review);
                db.SaveChanges();

                TempData["Message"] = "Your review was added successfully!";
                return RedirectToAction("About", "HomePage");
            }
        }

    }
}
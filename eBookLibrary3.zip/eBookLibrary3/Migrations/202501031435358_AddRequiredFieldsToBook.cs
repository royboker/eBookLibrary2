﻿namespace eBookLibrary3.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class AddRequiredFieldsToBook : DbMigration
    {
        public override void Up()
        {
            AlterColumn("dbo.Books", "Author", c => c.String(nullable: false, maxLength: 100));
            AlterColumn("dbo.Books", "Publisher", c => c.String(nullable: false, maxLength: 100));
            AlterColumn("dbo.Books", "ImageUrl", c => c.String(nullable: false, maxLength: 1000));
            AlterColumn("dbo.Books", "AgeLimit", c => c.String(nullable: false));
            AlterColumn("dbo.Books", "Genre", c => c.String(nullable: false, maxLength: 100));
            AlterColumn("dbo.Books", "Summary", c => c.String(nullable: false, maxLength: 1000));
        }
        
        public override void Down()
        {
            AlterColumn("dbo.Books", "Summary", c => c.String(maxLength: 1000));
            AlterColumn("dbo.Books", "Genre", c => c.String(maxLength: 100));
            AlterColumn("dbo.Books", "AgeLimit", c => c.String());
            AlterColumn("dbo.Books", "ImageUrl", c => c.String(maxLength: 1000));
            AlterColumn("dbo.Books", "Publisher", c => c.String(maxLength: 100));
            AlterColumn("dbo.Books", "Author", c => c.String(maxLength: 100));
        }
    }
}

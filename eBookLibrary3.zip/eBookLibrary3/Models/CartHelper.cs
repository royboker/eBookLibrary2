﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace eBookLibrary3.Models
{
    //מחלקה עבור ניהול עגלת קניות
    public static class CartHelper
    {
        public static List<CartItem> GetCart()
        {
            if (HttpContext.Current.Session["Cart"] == null)
            {
                HttpContext.Current.Session["Cart"] = new List<CartItem>();
            }
            return HttpContext.Current.Session["Cart"] as List<CartItem>;
        }

        //הוספה לעגלה
        public static void AddToCart(CartItem item)
        {
            var cart = GetCart();
            cart.Add(item);
            HttpContext.Current.Session["Cart"] = cart;
        }
        //הסרה מן העגלה
        public static void RemoveFromCart(int bookId)
        {
            var cart = GetCart();
            var item = cart.FirstOrDefault(i => i.BookId == bookId);
            if (item != null)
            {
                cart.Remove(item);
            }
            HttpContext.Current.Session["Cart"] = cart;
        }
        //ריקון העגלה
        public static void ClearCart()
        {
            HttpContext.Current.Session["Cart"] = new List<CartItem>();
        }
        //שמירת עגלה זמנית במידה והיו ספרים לפני
        public static void SaveCartToTemporary()
        {
            var cart = GetCart();
            HttpContext.Current.Session["TemporaryCart"] = new List<CartItem>(cart);
        }
        //שליפ העגלה הזמנית במקרה ונבחר ספר במצב של קנה עכשיו
        public static void RestoreCartFromTemporary()
        {
            if (HttpContext.Current.Session["TemporaryCart"] != null)
            {
                var tempCart = HttpContext.Current.Session["TemporaryCart"] as List<CartItem>;
                HttpContext.Current.Session["Cart"] = tempCart ?? new List<CartItem>();
                HttpContext.Current.Session["TemporaryCart"] = null;
            }
        }
       
        public static void ClearCartExcept(int bookId)
        {
            var cart = GetCart();
            var selectedItem = cart.FirstOrDefault(i => i.BookId == bookId);
            if (selectedItem != null)
            {
                HttpContext.Current.Session["Cart"] = new List<CartItem> { selectedItem };
            }
            else
            {
                ClearCart();
            }
        }


    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace eBookLibrary3.Models
{
    public class Book
    {
        public int BookId { get; set; }

        [Required]
        [StringLength(200)]
        public string Title { get; set; }
        [Required]
        [StringLength(100)]
        public string Author { get; set; }
        [Required]
        [StringLength(100)]
        public string Publisher { get; set; }
        [Required]
        public decimal Price { get; set; }

        public int Stock { get; set; }

        // שדה URL לתמונה
        [Required]
        [StringLength(1000)]
        public string ImageUrl { get; set; }

        //  מחיר קנייה(מחיר הנחה) אם קיים
        public decimal BuyPrice { get; set; }

        // מחיר השאלה
        public decimal BorrowPrice { get; set; }

        // שנה של פרסום
        [Required]
        public int YearOfPublication { get; set; }

        // גיל מינימלי לקריאה
        [Required]
        public string AgeLimit { get; set; }

        // ז'אנר הספר
        [Required]
        [StringLength(100)]
        public string Genre { get; set; }

        // פורמט הספר
        [StringLength(100)]
        public string Format { get; set; }

        public float Popularity { get; set; } = 0.0f; // ברירת מחדל: 0
        public int ReviewCount { get; set; } = 0; // ברירת מחדל: 0

        [Required]
        [StringLength(1000)]
        public string Summary { get; set; }

        public DateTime? DiscountStartDate { get; set; }
    }
}